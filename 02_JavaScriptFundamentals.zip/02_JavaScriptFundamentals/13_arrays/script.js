// create some arrays
const numbers = [1,2,3,4,5];
const numbers2 = new Array(3,4,5,6);
const fruit = ['apple', 'banana', 'orange', 'pear'];
const mixed = [22, 'hello', true, undefined, null, {a:1, b:1}, new Date()];

let val;

// Get array length
val = numbers.length;

// check if array
val = Array.isArray(numbers);

// get a single value by index
val = numbers[3];

// insert into array
numbers[2] = 100;

// find index of value
val = numbers.indexOf(4);

// mutating with arrays
numbers.push(250); // add onto end
numbers.unshift(120); // add to front
numbers.pop(); // take off of the end
numbers.shift(); // take off the front
numbers.splice(1,1); // splice where to start and end
numbers.reverse(); // reverse the array
val = numbers.concat(numbers2); // concatenate second array to first
val = fruit.sort(); // sort the array, sorts numbers by first digit

// sort with compare function, puts numbers in order
val = numbers.sort(function(x, y){
    return x-y;
});

// sort numbers in reverse order
val = numbers.sort(function(x, y){
    return y-x;
});

// find
function under50(num){
    return num < 50;
}

val = numbers.find(under50);

console.log(numbers);
console.log(val);
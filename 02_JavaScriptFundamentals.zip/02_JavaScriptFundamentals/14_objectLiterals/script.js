const person = {
    firstName: 'Steve',
    lastName: 'Smith',
    age: 30,
    email: 'steve@aol.com',
    hobbies: ['music', 'sports'],
    address: {
        city: 'Miami',
        state: 'FL'
    },
    getBirthYear: function(){
        return 1987;
    },
    getBirthYear2: function(){
        return 2021 - this.age; // need this keyword for something inside object
    }
}

let val;

val = person;

// get specific value
val = person.firstName;
val = person['firstName'];
val = person.age;
val = person.hobbies[1];
val = person.address.state;
val = person.address['city'];
val = person.getBirthYear(); // needs parentheses because it's a function


console.log(val);

const people = [
    {name: 'John', age: 30},
    {name: 'Mike', age: 23}, 
    {name: 'Nancy', age: 40}
];

for(let i = 0, i < people.length; i++){
    console.log(people[i].name);
}
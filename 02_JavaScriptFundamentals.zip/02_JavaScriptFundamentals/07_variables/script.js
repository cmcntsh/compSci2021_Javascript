// var, let, const

// var was used a lot in the past, let and const are used more now

var name1 = 'John';
console.log(name1);
name1 = 'Steve';
console.log(name1);

// creating a variable without assigning anything will give undefined
var newVar //initialized without a value
console.log(newVar)

// you can assign a value later
newVar = 'Hello'
console.log(newVar)

// variable names can only have letters, numbers, _ (underscore), $ (dollar sign)
// variable names can't start with a number

// multiword variables
var firstName = 'John'; // camel case (used in JavaScript)
var first_name = 'John'; // snake case (common in Python)
var FirstName = 'John'; // Pascal case (first letter capitalized, not the JS convention for variables)
var firstname = 'John'; // all lower case (don't use!)

// Comment a lot of lines at once
// Select the lines, Ctrl-forward slash
// Can do the same thing to uncomment them.

// let
// Works like var, but the block scope is different.
let name2 = 'John';
console.log(name2);
name2 = 'Steve';
console.log(name2);
let name3; //Can also initialize without defining it.
console.log(name3);

// const - stands for constant
const name4 = 'Jane';
console.log(name4);
// can't reassign
//name4 = 'Sally'; // You'll see error in console.
// must assign a value, can't leave it undefined
//name5 // You'll see an error in the console.

// People get confused about changing objects created with const.
const person = {
    name: 'John',
    age: 30
}
console.log(person);

person.name = "Sara";
console.log(person); //This works


const numbers = [1,2,3,4,5];
console.log(numbers);
numbers.push(6); // Can add using this method.
console.log(numbers);

// Can't reassign.
//numbers = [1,2,3,4,5,6,7]; // You'll see an eror in the console.

// You can mutate variables created with const, but you can't reassign them with a new primitve value.
// Don't use const if the value will change, or if you need to initialize, or in loops.
const num1 = 100;
const num2 = 50;

let val;

// operators + - * / %

// math object - has methods
val = Math.PI;
val = Math.E;
val = Math.round(2.4);
val = Math.ceil(2.4);
val = Math.floor(2.4);
val = Math.sqrt(64);
val = Math.pow(8,2);
val = Math.min(1,2,3,4);
val = Math.max();
val = Math.random(); // decimals
val = Math.floor(Math.random() * 20 + 1); // random whole numbers between 1 and 20


console.log(val);
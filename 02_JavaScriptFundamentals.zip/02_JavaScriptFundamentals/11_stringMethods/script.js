const firstName = 'William';
const lastName = 'Johnson';
const str = 'Hello there.'

let val;

val = firstName + lastName;

// concatenation
val = firstName + ' ' + lastName;

// append +=

val = 'first';
val += 'last';

// nested quotes
// alternate double quotes and single quotes
val = "That's great!"
// use escape character backslash \
val = 'That\'s great!'

// length property (not a method so no parentheses at the end)
val = firstName.length;

// concate method
val = firstName.concat(' ',lastName);

// change case
val = firstName.toUpperCase();
val = firstName.toLowerCase();

// treat string as read-only array
val = firstName[0];
val = firstName.charAt('0');

// get index of character
// if character not present result will be -1
val = firstName.indexOf('a');
val = firstName.lastIndexOf('a');

// get last character
val = firstName.charAt(firstName.length -1);

// substring
val = firstName.substring(0,4);

// slice - used with arrays and strings
val = firstName.slice(0,4);
val = firstName.slice(-3); // start from back and get 3

// split at separator
val = str.split(' ');

// replace
val = str.replace('old', 'new');

// includes - tests if present
val = str.includes('Hello');

console.log(val);
// Global scope
var a = 1;
let b = 2;
const c = 3;

// function scope
function test(){
    var a = 4;
    let b = 5;
    const c = 6;
    console.log('Function Scope: ', a, b, c);
}

test();

// block scope
if(true) {
    var a = 4; // var in the if statement will change the global variable
    let b = 5; // let doesn't change the global variable
    const c = 6; // const doesn't change the global variable
    console.log('Block Scope: ', a, b, c);
}

// var changes the global scope, let doesn't change the global scope
for(let a = 0; a < 10; a++) {
    console.log(`Loop: ${a}`);
}

console.log('Global Scope: ', a, b, c);


/*
 Primitive data types
 - stored directly in teh location the variable accesses
 - stored in the stack

 Reference data types
 - Accessed by reference
 - objects that are stored on the heap (dynamically allocated memory)
 - a pointer to a location in memory

 */

/*
JS is a dynamically typed language
- types are associated with values not variables
- the same variable can hold multiple types
- we do not need to specify types
- most other languages are statically typed (Java, C#, C++)
- There are supersets of JS and addons to allow static typing (TypeScript, Flow)
*/

// 6 primitive data types
// string
const name1 = 'John';
console.log(typeof name1);

// number
const age = 13;
console.log(typeof age);

// boolean
const hasKids = false;
console.log(typeof hasKids);

// null
const car = null;
console.log(typeof car);

// undefined
let someVar;
console.log(typeof someVar);

// symbols (ES6)
const sym = Symbol();
console.log(typeof sym);

// Reference data types - considered objects
// arrays
const hobbies = ['movies', 'music'];
console.log(typeof hobbies);

// object literals
const address = {
    city: 'Boston',
    state: 'MA'
};
console.log(typeof address);

// functions
// no example given

// dates
const today = new Date();
console.log(typeof today);

// anything else
//no example given

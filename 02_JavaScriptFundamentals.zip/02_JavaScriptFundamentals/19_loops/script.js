// for loop

for(let i = 0; i < 10; i++){
    if(i === 2){
        console.log('2 is my favorite number');
        continue: // stops loop here and goes to next iteration
    }

    if(i === 5){
        break: // breaks out of the loop
    }

    console.log(i);
}

// while loop (use for when number know and while when unknown)

let i = 0;

while(i < 10){
    console.log('Number ' + i);
    i++;
}

// do while loop (will always run at least once)

let i = 0;

do {
    console.log('Number' + i);
    i++;
}

while(i < 10);

// using loops to loop through arrays
// there are specific methods for iterating through arrays which are better
// this is just a learning exercise to demonstrate loops

const cars = ['Ford', 'Chevy', 'Honda', 'Toyota']

for(let i = 0; i < cars.length; i++){
    console.log(cars[i]);
}

// for each loop
cars.forEach(function(car){
    console.log(car);
});

// for each loop with additional options
cars.forEach(function(car, index, array){
    console.log(`${index} : ${car}`);
    console.log(array);
});

// map (returns a different array)

const users = [
    {id: 1, name: 'John'},
    {id: 2, name: 'Sara'},
    {id: 3, name: 'Karen'}
]

const ids = users.map(function(user){
    return user.id;
});

console.log(ids);

// for in loop

const uer = {
    firstName: 'John',
    lastName: 'Doe',
    age: 40
}

for(let x in user){
    console.log(x);
    console.log(`${x} : ${user[x]}`);
}
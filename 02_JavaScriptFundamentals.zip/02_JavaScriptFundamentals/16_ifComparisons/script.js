// similar structure to other c based languages
// if(something){
//     do something
// } else {
//     do something else
// }

const id = 100;

// equal to
if(id == 100){
    console.log('CORRECT');
} else {
    console.log('INCORRECT');
}

// operators == (value)  !=  === (value & type) !==


// test if undefined
if(typeof id !== undefined){
    console.log(`The ID is ${id}`);
} else {
    console.log(`NO ID`);
}

// > >= < <=

// if else

const color = 'yellow';
if(color==='red'){
    console.log('Color is red');
} else if(color==='blue'){
    console.log('Color is blue')
} else {
    console.log('Color is not red or blue');
}

// logical operators && (and) || (or) 

// ternary operator
console.log(id === 100 ? 'CORRECT' : 'INCORRECT');

// without braces (they're optional, but recommended to use)
if(id === 100)
  console.log('CORRECT');
else
  console.log('INCORRECT');
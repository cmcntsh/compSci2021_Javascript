// converting variables from one type to another

val = String(); // function converts to a string
val = (5).toString(); // method converts to a string
val = Number(); // function converts to a number
val = parseInt('100'); // function converts to an integer
val = parseFloat('100.31') // Function converts to a decimal

// JavaScript will do type coersion



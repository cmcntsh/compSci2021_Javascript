//alert('hello'); //uncomment to run

// Single line comments

/*
Multiline comments
*/

/*
Open the console in Chrome - F12 or Ctrl-Shift-i
*/

/*
You can execute code directly from the console.
Type any of the code you see below directly in the console to try it.
*/

// log to console
console.log('hello');
console.log(123);
console.log(true);
var greeting = 'Hello';
console.log(greeting); // log variables
console.log([1,2,3,4]); // log arrays
console.log({a:1, b:2}); // log objects
console.table({a:1, b:2});
console.error('My error message shows up in red.');
//console.clear(); // will clear the console
console.warn('My warning message shows up in yellow.');

// time how long something takes to execute
console.time('Hello');
    console.log('timing line');
    // Shift-Alt-down arrow will copy a line down.
    console.log('timing line');
    console.log('timing line');
    console.log('timing line');
    console.log('timing line');
    console.log('timing line');
    console.log('timing line');
    console.log('timing line');
    // Select multiple lines and hit tab to move them all over at the same time.
console.timeEnd('Hello');
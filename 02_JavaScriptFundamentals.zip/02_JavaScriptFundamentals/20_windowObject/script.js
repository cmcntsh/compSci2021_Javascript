// type window in console to see all elements in window object

// window methods

// window objects

// window properties

// Alert
// alert('Hello World');

// prompt

// const input = prompt();
// alert(input);

// confirm

// if(confirm('Are you sure?')){
//     console.log('YES');
// } else {
//     console.log('NO');
// }

//properties

let val;

// outer height and width, outside the scroll bars
val = window.outerHeight;
val = window.outerWidth;

// inside the scroll bars
val = window.innerHeight;
val = window.innerWidth;

// scroll points
val = scrollY;
val = scrollX;

// location object
val = window.location;
val = window.location.hostname;
val = window.location.port;
val = window.location.href;
val = window.location.search; // shows parameters in address window after ?

// redirect
//window.location.href = 'http://google.com'

// reload page
//window.location.reload();

// history object

//window.history.go(); // take you back to where you came from
//val = window.history.length;

// navigator object
val = window.navigator;
val = window.navigator.appName;
val = window.navigator.appVersion;
val = window.navigator.userAgent;
val = window.navigator.platform;
val = window.navigator.vendor;
val = window.navigator.language;

console.log(val);

let val;

const today = new Date(); // date is an object
//const birthday = new Date('9-10-1981 11:25:00');
let birthday = new Date('9-10-1981 11:25:00');
let birthday = new Date('September 10 1981');
let birthday = new Date('9/10/1981');

// lookup Date object on MDN documentation for more info

val = today;
// val = today.getMonth(); // 0 based so different than what we're used to
// val = today.getDate();
// val = today.getDay();
// val = today.getFullYear();
// val = today.getHours();
// val = today.getMinutes();
// val = today.getSeconds();
// val = today.getMilliseconds();
// val = today.getTime(); // gives a timestamp, number seconds since 01/01/1970

// birthday.setMonth(2);
// birthday.setDate(12);
// birthday.setFullYear(1985);
// birthday.setHours(3);
// birthday.setMinutes(30);
// birthday.setSeconds(25);


console.log(today);
console.log(typeof val);
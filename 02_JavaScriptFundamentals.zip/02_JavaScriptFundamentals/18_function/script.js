// function declarations

function greet(){
    //console.log('Hello'); // usually don't print directly, use return
    return 'Hello';
}

// need to call function to get output
console.log(greet());

// function with a parameter

function greet(firstName = 'John'){ // can set default for parameter ES6
    //console.log('Hello'); // usually don't print directly, use return
    //if(typeof firstName === 'undefined'){firstName = 'John'} // old way to set default for parameter
    return 'Hello' + firstName;
}

// need to call function to get output
console.log(greet('John'));

// can have multiple parameters separated by comma

// function expressions (assign function to variable)
// a function declaration uses form of function square(){}

const square = function(x = 3){
    return x*x;
}

console.log(square(8));

// immediately invokable function expressions aka IIFEs
// a function that you declare and run at the same time

(function(){
    console.log('IIFE Ran..');
})();

// with parameter
// These are usfuls with some design patterns like the module pattern (will learn later)

(function(name){
    console.log('Hello ' + name);
})('Brad'); // The parameter gets submitted down here.

// property methods

const todo = {
    add: function(){
        console.log('Add todo..');
    },
    edit: function(id){
        console.log(`Edit todo ${id}`);
    }
}

todo.add();
todo.edit(22);

// Can also define function outside of object

todo.delete = function(){
    console.log('Delete todo...');
}

todo.delete();